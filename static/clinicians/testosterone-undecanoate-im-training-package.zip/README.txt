GAMSA training package: testosterone undecanoate 1000 mg/4 mL by ventrogluteal intramuscular injection
Version 2.6 (7 November 2026); first issued 5 October 2025. Next review: 24 October 2027.
Prepared by Theodore South, BPharm (Hons), registered pharmacist, Adelaide
Current version: https://gamsa.au/medicines/testosterone-undecanoate
© 2026 GAMSA. All rights reserved. Check gamsa.au/clinicians for the current version.
Questions or corrections: gamsaenquiries@gmail.com

Contents (all five documents version 2.6, 7 November 2026; the after-injection handout version 1.0, 7 November 2026)
  testosterone-undecanoate-im-adverse-event-form.pdf
      Adverse event reporting and escalation form (2 pages, A4, fillable form, GAMSA-TU-AEF)
  testosterone-undecanoate-im-clinic-audit-tool.pdf
      Clinic audit tool (2 pages, A4 landscape, fillable form, GAMSA-TU-AUD)
  testosterone-undecanoate-im-competency-checklist.pdf
      Competency assessment checklist (2 pages, A4, fillable form, GAMSA-TU-COMP)
  testosterone-undecanoate-im-sop-and-training-guide.pdf
      Standard operating procedure and training guide (9 pages, A4, GAMSA-TU-SOP)
  testosterone-undecanoate-im-treatment-room-card.pdf
      Treatment-room card: print and laminate (1 page, A4 landscape, GAMSA-TU-CARD)
  testosterone-undecanoate-im-after-injection-handout.pdf
      After your long-acting testosterone injection: a handout for patients (1 page, A4, GAMSA-TU-AFTER)

Also in version 2.6 (7 November 2026): all five documents
  - The adverse event form, clinic audit tool and treatment-room card move from 2.4 to 2.6, so the package
    carries one version.
  - Every footer says "© 2026 GAMSA. All rights reserved." in place of "Uncontrolled when printed."
  - The PDFs are locked: they open without a password and can be filled in and printed, but not edited.
    To adapt a document to local policy, contact gamsaenquiries@gmail.com.
  - Treatment-room card: the amendment table is removed, as in the other documents.

What changed in version 2.6 (7 November 2026): SOP and competency checklist; new patient handout
  - SOP: "A respectful appointment" before the procedure: name and pronouns, explain each step and ask
    before touching, offer a chaperone or support person, uncover only the injection site, and use a
    professional interpreter (TIS National, 131 450) (AusPATH 2026; Canberra Health Services CHS25/344).
  - Competency is reassessed every 12 months, and sooner after a POME or anaphylaxis event at the clinic or
    after 6 months without giving this injection (GAMSA's suggestion; the clinic sets its own interval).
  - SOP Appendix D: the short quiz named in Section 2 (12 questions), with an answer key on the next page.
  - Competency checklist: new criterion 1a (respectful appointment) and a reassessment row (reassess by,
    reason if sooner, reassessed on), all fillable; the comments box has 3 lines instead of 4.
  - New: a one-page after-injection handout for patients (what is normal, when to ring 000, when to contact
    the clinic, the next injection, reporting a side effect). The adverse event form's "written
    information" tick refers to it.
  - The amendment tables were removed from the documents (gamsa.au v19.5); this file keeps the history.

What changed in version 2.5 (6 November 2026): SOP and competency checklist only
  - Patient identity: at least three approved identifiers (for example full name, date of birth, and address
    or medical record number), never sex or gender; use the name the person uses (Canberra Health Services
    CHS25/344; AusPATH 2026).
  - Hand hygiene at the 5 Moments (Australian Commission on Safety and Quality in Health Care, 2023): a line
    above the procedure steps, step 3 now "Clean your hands and prepare the site", and hand rub in the
    equipment list.
  - A box on what to do after a needlestick or sharps injury or a blood splash (NSW Health GL2024_002;
    NIOSH 2012-123).
  - Z-track may be used to reduce leakage; it is not in the Product Information, so follow local policy.
  - Scope: registered pharmacists with accredited injection training, where their state or territory allows
    it and their pharmacy has the governance in place.
  - Competency checklist: criterion 1 (three identifiers) reworded; new criteria 4a (hand hygiene) and 12a
    (needlestick and blood splash), each with fillable Yes/No and Comments fields. Sources [13] to [16]
    added to both documents. The steps keep their numbers, so the treatment-room card is unchanged (2.4).

What changed in version 2.4 (31 October 2026)
  - SOP Figure 2 and the treatment-room card now use the ventrogluteal drawing from the patient pages on
    gamsa.au: the side of the hip, with the three bony landmarks numbered 1 to 3 as in the key beside it
    and the injection site as a dot in the middle of the V. SOP Figure 1 step 1 is worded as on the site.
  - Every document gives a contact for questions or corrections: gamsaenquiries@gmail.com (in the footer
    or bottom line), and the amendment tables have a 2.4 row.
  - No clinical instruction changed. Next review date and document IDs are unchanged.

What changed in version 2.3 (23 and 24 October 2026)
  - Document control in every document: a document ID (shown above), an amendment table (versions 2.0 to 2.3),
    "Next review: 24 October 2027" and "Uncontrolled when printed. Check gamsa.au/clinicians for the current
    version." The treatment-room card also says "Check the QR code for the current version".
  - Treatment-room card: the "3 Landmark and inject" heading now comes before the drawing and its key, so the
    key is read after its heading. The card is now version 2.3, like the other four documents.
  - SOP Figure 1 (the appointment, step by step) now matches the patient pages on gamsa.au: step 5 starts
    with "Important:" (stay at least 30 minutes), so it stands out in black and white as well as in colour,
    and step 6 gives the first interval (about 6 weeks after the first dose, then usually every 10 to 14
    weeks).
  - The three forms (adverse event form, competency checklist, clinic audit tool) can now be filled in on
    screen and read with a screen reader: every tick box has a field name and a spoken label taken from its
    row, and every write-in box (names, dates, times, batch, comments, signatures) is a labelled text field.
  - No clinical instruction changed.

What changed in version 2.2 (18 October 2026)
  - New layout: one type and colour system, A4 with 18 mm margins, every table the full text width,
    header rows that repeat, larger tick boxes, two-line footer with Page X of Y; the appointment steps
    (Figure 1) and the landmark key are now real text; the treatment-room card is in four columns with
    an EMERGENCY column that keeps its weight when printed in black and white. The SOP is now 6 pages.
  - The POME escalation line is the same in every document: call 000 immediately for severe breathing
    difficulty, collapse or signs of anaphylaxis.
  - References re-checked on 18 October 2026: ASCIA anaphylaxis guideline October 2026 edition (same doses
    and steps); Product Information links now go to the Medicine Finder; AusPATH page numbers 22, 56, 58.

What changed in version 2.1 (16 October 2026)
  - Observation after each injection: at least 30 minutes (was 15). POME typically presents within
    30 minutes (AusPATH Australian Standards of Care, 2026); the Product Information gives no fixed time.
  - A pregnancy test before each injection is recommended for anyone who could become pregnant;
    testosterone is contraindicated in pregnancy (Product Information section 4.6).
  - POME: symptoms usually resolve within 30 minutes to a few hours (Pastuszak 2020; AusPATH 2026).

Version 2.0 (2 October 2026): the GAMSA edition of the documents first prepared on 5 October 2025, issued as
a package of five (the treatment-room card and the clinic audit tool were added).

These are templates for adaptation to local policy, offered freely; they are not endorsed by any health
service. Clinics remain responsible for their own procedures, credentialling and emergency arrangements.
Where these documents and the Product Information differ, the Product Information prevails.


GAMSA training package: testosterone undecanoate 1000 mg/4 mL by ventrogluteal intramuscular injection
Version 2.2, 18 October 2026 (first issued 5 October 2025)
Prepared by Theodore South, BPharm (Hons), registered pharmacist, Adelaide
Current version: https://gamsa.au/medicines/testosterone-undecanoate

Contents
  testosterone-undecanoate-im-adverse-event-form.pdf
      Adverse event reporting and escalation form (2 pages, A4, fillable check boxes)
  testosterone-undecanoate-im-clinic-audit-tool.pdf
      Clinic audit tool (2 pages, A4 landscape, fillable check boxes)
  testosterone-undecanoate-im-competency-checklist.pdf
      Competency assessment checklist (2 pages, A4, fillable check boxes)
  testosterone-undecanoate-im-sop-and-training-guide.pdf
      Standard operating procedure and training guide (6 pages, A4)
  testosterone-undecanoate-im-treatment-room-card.pdf
      Treatment-room card: print and laminate (1 page, A4 landscape)

What changed in version 2.2 (18 October 2026)
  - New layout: one type and colour system, A4 with 18 mm margins, every table the full text width,
    header rows that repeat, larger tick boxes, two-line footer with Page X of Y; the appointment steps
    (Figure 1) and the landmark key are now real text; the treatment-room card is in four columns with
    an EMERGENCY column that keeps its weight when printed in black and white. The SOP is now 6 pages.
  - The POME escalation line is the same in every document: call 000 immediately for severe breathing
    difficulty, collapse or signs of anaphylaxis.
  - References re-checked on 18 October 2026: ASCIA anaphylaxis guideline October 2026 edition (same doses
    and steps); Product Information links now go to the Medicine Finder; AusPATH page numbers 22, 56, 58.

What changed in version 2.1 (16 October 2026)
  - Observation after each injection: at least 30 minutes (was 15). POME typically presents within
    30 minutes (AusPATH Australian Standards of Care, 2026); the Product Information gives no fixed time.
  - A pregnancy test before each injection is recommended for anyone who could become pregnant;
    testosterone is contraindicated in pregnancy (Product Information section 4.6).
  - POME: symptoms usually resolve within 30 minutes to a few hours (Pastuszak 2020; AusPATH 2026).

These are templates for adaptation to local policy, offered freely; they are not endorsed by any health
service. Clinics remain responsible for their own procedures, credentialling and emergency arrangements.
Where these documents and the Product Information differ, the Product Information prevails.


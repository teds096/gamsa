GAMSA training package: testosterone undecanoate 1000 mg/4 mL by ventrogluteal intramuscular injection
Version 2.1, 16 October 2026 (first issued 5 October 2025)
Prepared by Theodore South, BPharm (Hons), registered pharmacist, Adelaide
Current version: https://gamsa.au/medicines/testosterone-undecanoate

Contents
  testosterone-undecanoate-im-adverse-event-form.pdf
      Adverse event reporting and escalation form (2 pages, A4, fillable check boxes)
  testosterone-undecanoate-im-clinic-audit-tool.pdf
      Clinic audit tool (2 pages, A4 landscape, fillable check boxes)
  testosterone-undecanoate-im-competency-checklist.pdf
      Competency assessment checklist (2 pages, A4, fillable check boxes)
  testosterone-undecanoate-im-sop-and-training-guide.pdf
      Standard operating procedure and training guide (7 pages, A4)
  testosterone-undecanoate-im-treatment-room-card.pdf
      Treatment-room card: print and laminate (1 page, A4 landscape)

What changed in version 2.1
  - Observation after each injection: at least 30 minutes (was 15). POME typically presents within
    30 minutes (AusPATH Australian Standards of Care, 2026); the Product Information gives no fixed time.
  - A pregnancy test before each injection is recommended for anyone who could become pregnant;
    testosterone is contraindicated in pregnancy (Product Information sections 4.3 and 4.6).
  - POME: symptoms usually resolve within 30 minutes to a few hours (Pastuszak 2020; AusPATH 2026).
  - A4 paper; tagged, accessible PDFs with bookmarks and clickable links; tick-able check boxes on the forms;
    references re-checked on 16 October 2026.

These are templates for adaptation to local policy, offered freely; they are not endorsed by any health
service. Clinics remain responsible for their own procedures, credentialling and emergency arrangements.
Where these documents and the Product Information differ, the Product Information prevails.

